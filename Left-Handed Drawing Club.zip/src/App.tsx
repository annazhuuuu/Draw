import { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { DrawingCanvas } from './components/DrawingCanvas';
import { Library } from './components/Library';

export interface SavedDrawing {
  id: string;
  imageData: string;
  caption: string;
  timestamp: number;
}

export type Screen = 'welcome' | 'drawing' | 'library';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [savedDrawings, setSavedDrawings] = useState<SavedDrawing[]>([]);

  const handleSaveDrawing = (imageData: string, caption: string) => {
    const newDrawing: SavedDrawing = {
      id: Date.now().toString(),
      imageData,
      caption,
      timestamp: Date.now(),
    };
    setSavedDrawings([...savedDrawings, newDrawing]);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {currentScreen === 'welcome' && (
        <WelcomeScreen onStart={() => setCurrentScreen('drawing')} />
      )}
      {currentScreen === 'drawing' && (
        <DrawingCanvas
          onNavigateToLibrary={() => setCurrentScreen('library')}
          onSaveDrawing={handleSaveDrawing}
        />
      )}
      {currentScreen === 'library' && (
        <Library
          drawings={savedDrawings}
          onBack={() => setCurrentScreen('drawing')}
        />
      )}
    </div>
  );
}
