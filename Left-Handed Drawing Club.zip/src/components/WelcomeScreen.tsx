interface WelcomeScreenProps {
  onStart: () => void;
}

export function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-12">
      <h1 className="text-4xl md:text-6xl text-center px-4">
        Left-Handed Drawing Club
      </h1>
      <button
        onClick={onStart}
        className="px-8 py-3 bg-white text-black hover:bg-gray-200 transition-colors"
      >
        Welcome
      </button>
    </div>
  );
}
