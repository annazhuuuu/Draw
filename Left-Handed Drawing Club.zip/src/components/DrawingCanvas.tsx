import { useRef, useState, useEffect } from 'react';
import { Palette, Eraser, Volume2, VolumeX, BookOpen } from 'lucide-react';

interface DrawingCanvasProps {
  onNavigateToLibrary: () => void;
  onSaveDrawing: (imageData: string, caption: string) => void;
}

const DRAWING_PROMPTS = [
  'Draw a circle',
  'Draw a square',
  'Draw a triangle',
  'Draw a heart',
  'Draw a star',
  'Draw a house',
  'Draw a tree',
  'Draw a flower',
  'Draw a cat',
  'Draw a sun',
];

const COLORS = ['#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

export function DrawingCanvas({ onNavigateToLibrary, onSaveDrawing }: DrawingCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushSize, setBrushSize] = useState(3);
  const [brushColor, setBrushColor] = useState('#ffffff');
  const [showBrushSettings, setShowBrushSettings] = useState(false);
  const [currentHint, setCurrentHint] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const pathRef = useRef<{ x: number; y: number }[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const updateCanvasSize = () => {
      const container = canvas.parentElement;
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    return () => window.removeEventListener('resize', updateCanvasSize);
  }, []);

  const playDrawSound = () => {
    if (!soundEnabled) return;
    const audioContext = new AudioContext();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    gainNode.gain.value = 0.1;
    
    oscillator.start();
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);
    oscillator.stop(audioContext.currentTime + 0.05);
  };

  const checkIfPathClosed = (path: { x: number; y: number }[]) => {
    if (path.length < 10) return false;
    
    const firstPoint = path[0];
    const lastPoint = path[path.length - 1];
    const distance = Math.sqrt(
      Math.pow(lastPoint.x - firstPoint.x, 2) + Math.pow(lastPoint.y - firstPoint.y, 2)
    );
    
    return distance < 20;
  };

  const fillClosedPath = (path: { x: number; y: number }[]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = brushColor;
    ctx.beginPath();
    ctx.moveTo(path[0].x, path[0].y);
    path.forEach(point => {
      ctx.lineTo(point.x, point.y);
    });
    ctx.closePath();
    ctx.fill();
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    setIsDrawing(true);
    pathRef.current = [{ x, y }];

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    pathRef.current.push({ x, y });

    ctx.strokeStyle = brushColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();

    playDrawSound();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    
    if (checkIfPathClosed(pathRef.current)) {
      fillClosedPath(pathRef.current);
    }
    
    setIsDrawing(false);
    pathRef.current = [];
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const generateHint = () => {
    const randomHint = DRAWING_PROMPTS[Math.floor(Math.random() * DRAWING_PROMPTS.length)];
    setCurrentHint(randomHint);
  };

  const saveCurrentDrawing = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const imageData = canvas.toDataURL();
    const caption = currentHint || 'Untitled Drawing';
    onSaveDrawing(imageData, caption);
    clearCanvas();
    setCurrentHint(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-white/20">
        <h1 className="text-2xl text-center">Left-Handed Drawing Club</h1>
      </div>

      {/* Canvas */}
      <div className="flex-1 relative">
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full h-full cursor-crosshair"
        />
        
        {/* Hint Display */}
        {currentHint && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white text-black px-4 py-2">
            {currentHint}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="p-4 border-t border-white/20">
        <div className="flex flex-wrap gap-2 justify-center">
          <button
            onClick={generateHint}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors"
          >
            Draw
          </button>
          
          <button
            onClick={clearCanvas}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2"
          >
            <Eraser className="w-4 h-4" />
            Clear
          </button>

          <button
            onClick={() => setShowBrushSettings(!showBrushSettings)}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2"
          >
            <Palette className="w-4 h-4" />
            Brush
          </button>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            Sound
          </button>

          <button
            onClick={saveCurrentDrawing}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors"
          >
            Save
          </button>

          <button
            onClick={onNavigateToLibrary}
            className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            Library
          </button>
        </div>

        {/* Brush Settings */}
        {showBrushSettings && (
          <div className="mt-4 p-4 border border-white/20 bg-black">
            <div className="mb-4">
              <label className="block mb-2">Thickness: {brushSize}px</label>
              <input
                type="range"
                min="1"
                max="20"
                value={brushSize}
                onChange={(e) => setBrushSize(Number(e.target.value))}
                className="w-full"
              />
            </div>
            
            <div>
              <label className="block mb-2">Color:</label>
              <div className="flex gap-2 flex-wrap">
                {COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => setBrushColor(color)}
                    className="w-10 h-10 border-2 hover:scale-110 transition-transform"
                    style={{
                      backgroundColor: color,
                      borderColor: brushColor === color ? '#888' : '#444',
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
