import { ArrowLeft } from 'lucide-react';
import { SavedDrawing } from '../App';

interface LibraryProps {
  drawings: SavedDrawing[];
  onBack: () => void;
}

export function Library({ drawings, onBack }: LibraryProps) {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="p-4 border-b border-white/20 flex items-center gap-4">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-white text-black hover:bg-gray-200 transition-colors flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>
        <h1 className="text-2xl">Library</h1>
      </div>

      {/* Drawings Grid */}
      <div className="p-8">
        {drawings.length === 0 ? (
          <div className="text-center text-white/60 py-12">
            No drawings yet. Start creating!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {drawings.map((drawing) => (
              <div key={drawing.id} className="border border-white/20 p-4">
                <img
                  src={drawing.imageData}
                  alt={drawing.caption}
                  className="w-full h-64 object-contain bg-black mb-2"
                />
                <p className="text-center">{drawing.caption}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
